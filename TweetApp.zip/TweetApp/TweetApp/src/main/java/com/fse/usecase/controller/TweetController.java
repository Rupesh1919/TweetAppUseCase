package com.fse.usecase.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.LoginServices;
import com.fse.usecase.service.TweetService;


@Controller
@RequestMapping("/login")
public class TweetController {
	
	@Autowired
	private LoginServices loginService;
	
	@Autowired
	private TweetService tweetService;
	@RequestMapping(value="/home", method = RequestMethod.POST)
	@ResponseBody
   public ModelAndView homepage(HttpServletRequest request,HttpServletResponse response) throws Exception
   {
//	 Users dummyData=new Users("sruthi","polaki","Female",new Date(),"test2.com","sruthi");
	 String f_name= request.getParameter("first");
	 String l_name= request.getParameter("last");
     String date2=request.getParameter("dueDate");
	 Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(date2);  
	 String gender= request.getParameter("gender");
	 String password= request.getParameter("password");
	 String email= request.getParameter("email");
	 Users users =new Users(f_name,l_name,gender,date1,email,password);
	 int k=loginService.registerUserIntoDB(users);
	 HttpSession session = request.getSession();
     session.setAttribute("username",email);
	 if(k>0)
	   return new ModelAndView("login");
	 return  new ModelAndView("home");
   }
	@RequestMapping(value="/tweets", method = RequestMethod.POST)
	@ResponseBody
   public ModelAndView TweetPage(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException ,Exception
   {
//	 Users dummyData=new Users("sruthi","polaki","Female",new Date(),"test2.com","sruthi");
	 String message= request.getParameter("message");
	 HttpSession session = request.getSession();
     String username=(String)session.getAttribute("username");
	 userTweets users =new userTweets(username,username,message);
	 int k=tweetService.postTweet(users);
	 if(k>0)
	   return new ModelAndView("login");
	 return  new ModelAndView("home");
   }
	@RequestMapping(value="/alltweets", method = RequestMethod.GET)
	@ResponseBody
	public String allTweets()
	{
		List<userTweets> allTweets=tweetService.getAllTweetsFroomDB();
		System.out.println(allTweets);
	
		return "success";
	}
	
	@RequestMapping(value="/allmytweets", method = RequestMethod.GET)
	@ResponseBody
	public String allmyTweets()
	{
		List<userTweets> allTweets=tweetService.getAllMyTweetsFromDB("rupesh@gmail.com");
		System.out.println(allTweets);
	
		return "success my tweets";
	}
	
	@RequestMapping(value="/updatepassword", method = RequestMethod.GET)
	@ResponseBody
	public String updatePassword()
	{
		int p=loginService.updatePassword("8688152919", "rupesh@gmail.com");
		
		if(p>0)
		return "updated password";
		
		return "Wasted";
	}
	
	@RequestMapping(value="/logincheck", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView loginCheck(HttpServletRequest request,HttpServletResponse response)
	{
		String email= request.getParameter("email");
		 String password= request.getParameter("password");
		boolean k=loginService.loginCheck(email, password);
		
		if(k==true)
		return new ModelAndView("tweetHome");
		
		return new ModelAndView("login");
	}
	

}
