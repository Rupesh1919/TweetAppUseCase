package com.fse.usecase.dao;

import java.util.List;

import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;

public interface TweetDao {

	public int registerUser(Users user);
	public List<userTweets> getAllTweets();
	public List<userTweets> getAllMyTweets(String email);
	public int updatePassword(String newPassword,String userEmail);
	public List<Users> allUsers();
	public int postTweet(userTweets tweets);
}
