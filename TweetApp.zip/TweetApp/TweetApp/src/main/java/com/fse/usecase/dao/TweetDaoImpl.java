package com.fse.usecase.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;


import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;

public class TweetDaoImpl implements TweetDao {

	private JdbcTemplate jdbcTemplate;

	public TweetDaoImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int registerUser(Users user) {

		String sqlstmt = "insert into users (firstName,lastName,gender,dob,email,password) values(?,?,?,?,?,?)";
		return jdbcTemplate.update(sqlstmt, user.getFirstName(), user.getLastName(), user.getGender(), user.getDob(),
				user.getEmail(), user.getPassword());

	}

	@Override
	public List<userTweets> getAllTweets() {
		
		String sql = "SELECT * FROM userTweets";
		List<userTweets> listContact = jdbcTemplate.query(sql, new RowMapper<userTweets>() {

			@Override
			public userTweets mapRow(ResultSet rs, int rowNum) throws SQLException {
				userTweets aContact = new userTweets();
	
				aContact.setUserName(rs.getString("userName"));
				aContact.setUserEmail(rs.getString("userEmail"));
				aContact.setTweetMsg(rs.getString("tweetMsg"));
				
				return aContact;
			}
			
		});
		
		return listContact;
	}

	@Override
	public List<userTweets> getAllMyTweets(String email) {
		String sql = "SELECT * FROM userTweets WHERE userEmail='" + email+"'";
		List<userTweets> listContact = jdbcTemplate.query(sql, new RowMapper<userTweets>() {

			@Override
			public userTweets mapRow(ResultSet rs, int rowNum) throws SQLException {
				userTweets aContact = new userTweets();
	
				aContact.setUserName(rs.getString("userName"));
				aContact.setUserEmail(rs.getString("userEmail"));
				aContact.setTweetMsg(rs.getString("tweetMsg"));
				
				return aContact;
			}
			
		});
		
		return listContact;
	}

	@Override
	public int updatePassword(String newPassword, String userEmail) {
		  String sql = "UPDATE users SET password=? WHERE email=?";
      return jdbcTemplate.update(sql, newPassword,userEmail);
	}

	@Override
	public List<Users> allUsers() {
		String sql = "SELECT * FROM users";
		List<Users> listContact = jdbcTemplate.query(sql, new RowMapper<Users>() {

			@Override
			public Users mapRow(ResultSet rs, int rowNum) throws SQLException {
				Users user = new Users();
	
				
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setGender(rs.getString("gender"));
				user.setDob(rs.getDate("dob"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				
				
				return user;
			}
			
		});
		
		return listContact;
	}

	@Override
	public int postTweet(userTweets tweets) {
		String sqlstmt = "insert into usertweets (userName,userEmail,tweetMsg) values(?,?,?)";
		return jdbcTemplate.update(sqlstmt, tweets.getUserName(), tweets.getUserEmail(), tweets.getTweetMsg());
	}

}
