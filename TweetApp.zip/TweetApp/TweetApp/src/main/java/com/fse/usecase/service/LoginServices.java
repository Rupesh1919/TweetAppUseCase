package com.fse.usecase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.dao.TweetDaoImpl;
import com.fse.usecase.model.Users;

@Service
public class LoginServices {

	@Autowired
	private TweetDao tweetDao;
	
	public int registerUserIntoDB(Users user)
	{
		int p=tweetDao.registerUser(user);
		return p;
	}
	
	public int updatePassword(String newPassword,String email)
	{
		int k=tweetDao.updatePassword(newPassword, email);
		return k;
	}
	
	public boolean loginCheck(String username,String passcode)
	{
		List<Users> allUsers=tweetDao.allUsers();
		for (Users users : allUsers) {
			if(users.getEmail().equals(username)&&users.getPassword().equals(passcode))
			{
				return true;
			}
		}
		return false;
	}
}
