package com.fse.usecase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;

@Service
public class TweetService {

	@Autowired
	private TweetDao tweetDao;
	
	public List<userTweets> getAllTweetsFroomDB(){
		
		List<userTweets> allTweets=tweetDao.getAllTweets();
		return allTweets;
	}
	
	public List<userTweets> getAllMyTweetsFromDB(String email)
	{
		return tweetDao.getAllMyTweets(email);
	}
	public int postTweet(userTweets user)
	{
		int p=tweetDao.postTweet(user);
		return p;
	}
}
