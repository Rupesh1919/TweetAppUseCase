package com.fse.usecase.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fse.usecase.model.PasswordChecker;
import com.fse.usecase.model.UserAddress;
import com.fse.usecase.model.UserphnNumber;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.Zipcode;
import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.LoginServices;
import com.fse.usecase.service.TweetService;

@Controller
public class HomeController {
	@Autowired
	private LoginServices loginService;
	@Autowired
	private TweetService tweetService;

	@RequestMapping(value="/")
	public ModelAndView test(HttpServletRequest request,HttpServletResponse response) throws IOException{
		HttpSession session = request.getSession();
		String username=(String)session.getAttribute("username");
		if(username!=null) {
			if(username.contains("@tweet.com")) {
				int a=loginService.updateAdminSessionDB(username);
			}else {
				int k=loginService.updateSessionDB(username);
			}
		}
		
		return new ModelAndView("home");
	}
	@RequestMapping(value="/register", method = RequestMethod.POST)
	@ResponseBody
   public ModelAndView homepage(HttpServletRequest request,HttpServletResponse response) throws Exception
   {
//	 Users dummyData=new Users("sruthi","polaki","Female",new Date(),"test2.com","sruthi");
	 String f_name= request.getParameter("first");
	 String l_name= request.getParameter("last");
     String date2=request.getParameter("dueDate");
	 Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(date2);  
	 String gender= request.getParameter("gender");
	 String password= request.getParameter("password");
	 String email= request.getParameter("email");
	 Users users =new Users(f_name,l_name,gender,date1,email,password);
	 int k=loginService.registerUserIntoDB(users);
	 HttpSession session = request.getSession();
     session.setAttribute("username",email);
     PasswordChecker passcheck=new PasswordChecker(email,password,password);
     int l=loginService.passwordChecker(passcheck);
	 if(k>0 && l>0)
	   return new ModelAndView("register2");
	 return  new ModelAndView("register");
   }
	
	@RequestMapping(value="/register2", method = RequestMethod.POST)
	@ResponseBody
   public ModelAndView register2(HttpServletRequest request,HttpServletResponse response) throws Exception
   {
//	 Users dummyData=new Users("rupesh","yadala","male",new Date(),"test2.com","rupesh");
	 HttpSession session = request.getSession();
	 String username=(String)session.getAttribute("username");
	 String phnNumber1= request.getParameter("phnNumber1");
	 String phnNumber2= request.getParameter("phnNumber2");
	 String city=request.getParameter("city");
	 String state=request.getParameter("state");
	 String country=request.getParameter("country");
	 String zipcode=request.getParameter("zipcode");
	 Zipcode zip=new Zipcode(zipcode,city,state,country);
	 int f=loginService.registerZipToDB(zip);
	 
	 UserphnNumber users =new UserphnNumber(username,phnNumber1,phnNumber2);
	 int k=loginService.registerUserOtherDetailsIntoDB(users);
	 String address1=request.getParameter("address1");
	 String address2=request.getParameter("address2");
	
	 UserAddress useradd=new UserAddress(username,address1,address2,zipcode);
	 int l=loginService.registerUserAddressIntoDB(useradd);
	 if(k>0 && l>0 && f>0)
	   return new ModelAndView("login");
	 return  new ModelAndView("register");
   }
	
	@RequestMapping(value="/register")
	public ModelAndView register(HttpServletResponse response) throws IOException{
		return new ModelAndView("register");
	}
	@RequestMapping(value="/login")
	public ModelAndView login(HttpServletResponse response) throws IOException{
		return new ModelAndView("login");
	}
	@RequestMapping(value="/tweetHome")
	public ModelAndView tweetHome(HttpServletResponse response) throws IOException{
		return new ModelAndView("tweetHome");
	}
	@RequestMapping(value="/post")
	public ModelAndView postTweet(HttpServletResponse response) throws IOException{
		return new ModelAndView("postTweet");
	}
	@RequestMapping(value="/resetPassword")
	public ModelAndView resetPassword(HttpServletResponse response) throws IOException{
		return new ModelAndView("resetPassword");
	}
//	@RequestMapping(value="/logout")
//	public String logout(HttpServletRequest request,HttpServletResponse response) throws IOException{
//		HttpSession session = request.getSession();
//		String username=(String)session.getAttribute("username");
//		int k=loginService.updateSessionDB(username);
//		
//		return "redirect/:";
//	}
//	@RequestMapping(value="/logincheck", method = RequestMethod.POST)
//	@ResponseBody
//	public ModelAndView loginCheck(HttpServletRequest request,HttpServletResponse response)
//	{
//		String email= request.getParameter("email");
//		 String password= request.getParameter("password");
//		boolean k=loginService.loginCheck(email, password);
//		
//		if(k==true) {
//			 HttpSession session = request.getSession();
//		     session.setAttribute("username",email);
//		     return new ModelAndView("tweetHome");
//		}else {
//			return new ModelAndView("login");
//		}
//	}
//	@RequestMapping(value="/allmytweets", method = RequestMethod.GET)
//	@ResponseBody
//	public ModelAndView allmyTweets(HttpServletRequest request,HttpServletResponse response)
//	{
//		HttpSession session = request.getSession();
//	     String username=(String)session.getAttribute("username");
//		List<userTweets> allTweets=tweetService.getAllMyTweetsFromDB(username);
//		ModelAndView model=new ModelAndView("myTweets");
//		model.addObject("task", allTweets);
//	
//		return model;
//	}
	
	
}
