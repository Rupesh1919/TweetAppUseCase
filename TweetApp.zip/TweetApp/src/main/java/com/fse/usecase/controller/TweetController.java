package com.fse.usecase.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fse.usecase.model.AdminPasswordChecker;
import com.fse.usecase.model.AdminSession;
import com.fse.usecase.model.AdminStatus;
import com.fse.usecase.model.PasswordChecker;
import com.fse.usecase.model.Post;
import com.fse.usecase.model.Tweet;
import com.fse.usecase.model.UserSession;
import com.fse.usecase.model.UserStatus;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.likes;
import com.fse.usecase.model.reportedDisclaimerMessage;
import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.LoginServices;
import com.fse.usecase.service.TweetService;


@Controller
//@RequestMapping("/login")
public class TweetController {
	
	@Autowired
	private LoginServices loginService;
	
	@Autowired
	private TweetService tweetService;
//	@RequestMapping(value="/post", method = RequestMethod.POST)
//	@ResponseBody
//   public ModelAndView TweetPage(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException ,Exception
//   {
//	 String message= request.getParameter("Message");
//	 String subject=request.getParameter("Subject");
//	 String totalMessage=subject+"-"+message;
//	 LocalDateTime date=java.time.LocalDateTime.now();
//	 HttpSession session = request.getSession();
//     String username=(String)session.getAttribute("username");
//	 userTweets users =new userTweets(username,username,totalMessage);
//	 int k=tweetService.postTweet(users);
//	 if(k>0)
//	   return new ModelAndView("postTweet");
//	 return  new ModelAndView("home");
//   }
	
	@RequestMapping(value="/post", method = RequestMethod.POST)
	@ResponseBody
   public ModelAndView TweetPage(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException ,Exception
   {
	 String message= request.getParameter("Message");
	 String subject=request.getParameter("Subject");
	 String totalMessage=subject+"-"+message;
	 java.util.Date date=new java.util.Date();  
	 Tweet tweet=new Tweet(totalMessage,date);
	 int l=tweetService.postTweet(tweet);
	 HttpSession session = request.getSession();
     String username=(String)session.getAttribute("username");
     Post post=new Post(username);
	 int k=tweetService.postedBy(post);
	 if(k>0 && l>0)
	   return new ModelAndView("postTweet");
	 return  new ModelAndView("home");
   }
	
	
	
	
	@RequestMapping(value="/tweets", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView allTweets()
	{
		List<likes> likes=tweetService.getLikesCount();
		List<userTweets> allTweets=tweetService.getAllTweetsFroomDB();
		ModelAndView model=new ModelAndView("viewAllTweet");
		model.addObject("task", allTweets);
		model.addObject("likes", likes);
		return model;
	}
	
//	@RequestMapping(value="/logout",method = RequestMethod.GET)
//	@ResponseBody
//	public String logout(HttpServletRequest request,HttpServletResponse response) throws IOException{
//		HttpSession session = request.getSession();
//		String username=(String)session.getAttribute("username");
//		int k=loginService.updateSessionDB(username);
//		if(k>0) {
//			return "redirect/:";
//		}
//		return "redirect/:";
//	}
	
	
	
	@RequestMapping(value="/allmytweets", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView allmyTweets(HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession session = request.getSession();
	     String username=(String)session.getAttribute("username");
	     if(username.contains("@tweet.com")) {
	    	 int activeUsers=loginService.getActiveUsers();
	    	 List<reportedDisclaimerMessage> repDis=tweetService.getDisclaimerTweets();
	    	 ModelAndView model=new ModelAndView("adminTweets");
	    	 model.addObject("task", repDis);
	 		model.addObject("count", activeUsers);
	 	
	 		return model;
	    	 
	     }
		List<userTweets> allTweets=tweetService.getAllMyTweetsFromDB(username);
		ModelAndView model=new ModelAndView("myTweets");
		model.addObject("task", allTweets);
	
		return model;
	}
//	
	@RequestMapping(value="/resetPassword", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView updatePassword(HttpServletRequest request,HttpServletResponse response)
	{
		HttpSession session = request.getSession();
	    String username=(String)session.getAttribute("username");
	    String password=request.getParameter("OldPassword");
		String newPassword= request.getParameter("NewPassword");
		
		boolean k=loginService.loginCheck(username, password);
		System.out.println(newPassword);
	     System.out.println(username);
	     int p=0;
	     int d=0;
	    if(k) {
	    	boolean f;
	    	if(username.contains("@tweet.com")) {
	    		 f=loginService.adminPasswordChecker(username, password, newPassword);
	    	}else {
	    		f=loginService.passwordChecker(username, password, newPassword);
	    	}
	    	
	    	if(f) {
	    		if(username.contains("@tweet.com")) {
	    			AdminPasswordChecker pass=loginService.getAdminPasswords(username);
	    	    	d=loginService.updateAdminPasswordChecker(username, password, newPassword,pass.getPass2());
	    	    	p=loginService.updateAdminPassword(newPassword, username);
	    			
	    		}else {
	    			PasswordChecker pass=loginService.getPasswords(username);
	    	    	d=loginService.updatePasswordChecker(username, password, newPassword,pass.getPass2());
	    	    	p=loginService.updatePassword(newPassword, username);
	    		}
	    	
	    	}
	    }else {
	    	 return new ModelAndView("resetPassword");
	    }
		
		
		if(p>0)
			 return new ModelAndView("resetPassword");
		 return  new ModelAndView("home");
	}
	
	@RequestMapping(value="/logincheck", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView loginCheck(HttpServletRequest request,HttpServletResponse response)
	{
		String email= request.getParameter("email");
		 String password= request.getParameter("password");
		boolean k=loginService.loginCheck(email, password);
		
		if(k==true) { 
			if(email.contains("@tweet.com")) {
				HttpSession session = request.getSession();
			    session.setAttribute("username",email);
			    boolean sessionFlag=true;
			     String status="Active";
			     java.util.Date date=new java.util.Date(); 
			     AdminSession userSession=new AdminSession(sessionFlag,status,date);
			     int f=loginService.insertIntoAdminSessionDB(userSession);
			     AdminStatus userStatus=new AdminStatus(email);
			     int l=loginService.insertIntoAdminStatusDB(userStatus);
			}else {
				HttpSession session = request.getSession();
			     session.setAttribute("username",email);
			     boolean sessionFlag=true;
			     String status="Active";
			     java.util.Date date=new java.util.Date(); 
			     UserSession userSession=new UserSession(sessionFlag,status,date);
			     int f=loginService.insertIntoSessionDB(userSession);
			     UserStatus userStatus=new UserStatus(email);
			     int l=loginService.insertIntoStatusDB(userStatus);
			}
			 
		     List<Users> users=loginService.getAllUsers();
			 ModelAndView model=new ModelAndView("tweetHome");
			 model.addObject("task",users);
		     return model;
		}else {
			return new ModelAndView("login");
		}
			
		
	}
	

}
