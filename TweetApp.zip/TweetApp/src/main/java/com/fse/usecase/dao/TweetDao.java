package com.fse.usecase.dao;

import java.sql.SQLException;
import java.util.List;

import com.fse.usecase.model.AdminDetails;
import com.fse.usecase.model.AdminPasswordChecker;
import com.fse.usecase.model.AdminSession;
import com.fse.usecase.model.AdminStatus;
import com.fse.usecase.model.PasswordChecker;
import com.fse.usecase.model.Post;
import com.fse.usecase.model.Tweet;
import com.fse.usecase.model.UserAddress;
import com.fse.usecase.model.UserSession;
import com.fse.usecase.model.UserStatus;
import com.fse.usecase.model.UserphnNumber;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.Zipcode;
import com.fse.usecase.model.likes;
import com.fse.usecase.model.reportedDisclaimerMessage;
import com.fse.usecase.model.userTweets;

public interface TweetDao {

	public int registerUser(Users user);
	public int register2User(UserphnNumber user);
	public int registerAddrUser(UserAddress useradd);
	public int passRegistry(PasswordChecker passcheck);
	public int registerZipToDB(Zipcode zip);
	public List<userTweets> getAllTweets();
	public boolean getZip(String zipcode);
	public int insertIntoSessionDB(UserSession userSession);
	public int insertIntoStatusDB(UserStatus userStatus);
	public List<userTweets> getAllMyTweets(String email);
	public PasswordChecker getPasswords(String username);
	public int updatePassword(String newPassword,String userEmail);
	public int updateSessionDB(String email);
	public int updatePasswordChecker(String username,String password,String newPassword,String pass3);
	public List<Users> allUsers();
//	public List<AdminDetails> allAdmins();
	public String getAdminPassword(String username);
	public int postTweet(Tweet tweets);
	public int postedBy(Post tweets);
	public int insertIntoAdminSessionDB(AdminSession adminSession);
	public int insertIntoStatusDB(AdminStatus adminStatus);
	public int updateAdminSessionDB(String username);
	public int getActiveUsers() throws SQLException;
	public AdminPasswordChecker getAdminPasswords(String username);
	public void insertAdminPassword(String username, String password, String password2);
	public int updateAdminPassword(String newPassword, String username);
	public int updateAdminPasswordChecker(String username, String password, String newPassword, String pass2);
	public int checkPasswordIsEmpty(String username);
	public List<likes> getLikesCount();
	public List<reportedDisclaimerMessage> getDisclaimerTweets();
}
