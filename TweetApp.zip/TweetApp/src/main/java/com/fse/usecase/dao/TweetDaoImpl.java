package com.fse.usecase.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;


import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.fse.usecase.model.AdminDetails;
import com.fse.usecase.model.AdminPasswordChecker;
import com.fse.usecase.model.AdminSession;
import com.fse.usecase.model.AdminStatus;
import com.fse.usecase.model.PasswordChecker;
import com.fse.usecase.model.Post;
import com.fse.usecase.model.Tweet;
import com.fse.usecase.model.UserAddress;
import com.fse.usecase.model.UserSession;
import com.fse.usecase.model.UserStatus;
import com.fse.usecase.model.UserphnNumber;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.Zipcode;
import com.fse.usecase.model.likes;
import com.fse.usecase.model.reportedDisclaimerMessage;
import com.fse.usecase.model.userTweets;
import com.mysql.cj.jdbc.CallableStatement;

public class TweetDaoImpl implements TweetDao {

	private JdbcTemplate jdbcTemplate;

	public TweetDaoImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int registerUser(Users user) {

		String sqlstmt = "insert into users (firstName,lastName,gender,dob,email,password) values(?,?,?,?,?,?)";
		return jdbcTemplate.update(sqlstmt, user.getFirstName(), user.getLastName(), user.getGender(), user.getDob(),
				user.getEmail(), user.getPassword());

	}
	
	public int register2User(UserphnNumber userphn) {

		String sqlstmt = "insert into userphnNumber (userEmail,phnNumber1,phnNumber2) values(?,?,?)";
		return jdbcTemplate.update(sqlstmt, userphn.getUserEmail() , userphn.getPhnNumber1(), userphn.getPhnNumber2());

	}
	
	public int registerAddrUser(UserAddress useradd) {

		String sqlstmt = "insert into userAddress (userEmail,address1,address2,zipcode) values(?,?,?,?)";
		return jdbcTemplate.update(sqlstmt,useradd.getUserEmail() , useradd.getAddress1(), useradd.getAddress2(),useradd.getZipcode());

	}
	public int registerZipToDB(Zipcode zip) {
		String sqlstmt = "insert into Zipcode (zipcode,city,state,country) values(?,?,?,?)";
		return jdbcTemplate.update(sqlstmt,zip.getZipcode() , zip.getCity(), zip.getState(),zip.getCountry());
		
	}
	public boolean getZip(String zipcode) {
		String sqlstmt = "select count(*) from Zipcode where zipcode=?";
		int count= this.jdbcTemplate.queryForObject(
				sqlstmt, new Object[] { zipcode }, Integer.class);
		if(count>0) {
			return true;
		}
		return false;
	}


	@Override
	public List<userTweets> getAllTweets() {
		
		String sql = "select p.userEmail as userName,p.userEmail as userEmail,t.tweetMsg from post p join tweet t on t.tweetId=p.tweetId";
//		List<userTweets> listContact = jdbcTemplate.query(sql, new RowMapper<userTweets>() {
//
//			@Override
//			public userTweets mapRow(ResultSet rs, int rowNum) throws SQLException {
//				userTweets aContact = new userTweets();
//	
//				aContact.setUserName(rs.getString("userName"));
//				aContact.setUserEmail(rs.getString("userEmail"));
//				aContact.setTweetMsg(rs.getString("tweetMsg"));
//				
//				return aContact;
//			}
//			
//		});
		RowMapper<userTweets> rowMapper=new RowMapper<userTweets>() {
			@Override
			public userTweets mapRow(ResultSet rs, int rowNum) throws SQLException {
	
				String userName=rs.getString("userName");
				String userEmail=rs.getString("userEmail");
				String tweetMsg=rs.getString("tweetMsg");
				
				return new userTweets(userName,userEmail,tweetMsg);
			}
		};
		return jdbcTemplate.query(sql,rowMapper);
	}

	@Override
	public List<userTweets> getAllMyTweets(String email) {
		String sql = "select p.userEmail as userName,p.userEmail as userEmail,t.tweetMsg from post p join tweet t on t.tweetId=p.tweetId where p.userEmail='" + email+"'";
		List<userTweets> listContact = jdbcTemplate.query(sql, new RowMapper<userTweets>() {

			@Override
			public userTweets mapRow(ResultSet rs, int rowNum) throws SQLException {
				userTweets aContact = new userTweets();
	
				aContact.setUserName(rs.getString("userName"));
				aContact.setUserEmail(rs.getString("userEmail"));
				aContact.setTweetMsg(rs.getString("tweetMsg"));
				
				return aContact;
			}
			
		});
		
		return listContact;
	}

	@Override
	public int updatePassword(String newPassword, String userEmail) {
		  String sql = "UPDATE users SET password=? WHERE email=?";
      return jdbcTemplate.update(sql, newPassword,userEmail);
	}
	
	
	@Override
	public int updateSessionDB(String email){
		String status="InActive";
		boolean sessionFlag=false;
		  String sql = "UPDATE userSession SET status=?,sessionFlag=? WHERE sessionId=(select max(sessionId) from userStatus where userEmail=?)";
	      return jdbcTemplate.update(sql,status,sessionFlag, email);
		}
	
	@Override
	public int updatePasswordChecker(String username,String password,String newPassword,String pass2) {
		  PasswordChecker p=new PasswordChecker();
		  String currentPassword=newPassword;
		  String password2=password;
		  String pass3=pass2;
		  String sql = "UPDATE passwordChecker SET currentpassword=?,pass1=?,pass2=?,pass3=? WHERE userEmail=?";
      return jdbcTemplate.update(sql, currentPassword,currentPassword,password2,pass3,username);
	}

	@Override
	public List<Users> allUsers() {
		String sql = "SELECT * FROM users";
		List<Users> listContact = jdbcTemplate.query(sql, new RowMapper<Users>() {

			@Override
			public Users mapRow(ResultSet rs, int rowNum) throws SQLException {
				Users user = new Users();
	
				
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setGender(rs.getString("gender"));
				user.setDob(rs.getDate("dob"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				
				
				return user;
			}
			
		});
		
		return listContact;
	}
	
	@Override
	public String getAdminPassword(String username) {
		String sql = "SELECT adminPassword FROM adminDetails where adminEmail=?";
		String password = (String) jdbcTemplate.queryForObject(
	            sql, new Object[] { username }, String.class);
		return password;
		
	}
	
//	@Override
//	public List<AdminDetails> allAdmins() {
//		String sql = "SELECT * FROM adminDetails";
//		List<Users> listContact = jdbcTemplate.query(sql, new RowMapper<Users>() {
//
//			@Override
//			public Users mapRow(ResultSet rs, int rowNum) throws SQLException {
//				AdminDetails user = new AdminDetails();
//	
//				
////				user.se(rs.getString("firstName"));
////				user.setLastName(rs.getString("lastName"));
////				user.setGender(rs.getString("gender"));
////				user.setDob(rs.getDate("dob"));
////				user.setEmail(rs.getString("email"));
////				user.setPassword(rs.getString("password"));
//				
//				
//				return user;
//			}
//			
//		});
//		
//		return listContact;
//	}

	@Override
	public int postTweet(Tweet tweets) {
		String sqlstmt = "insert into tweet (tweetMsg,postedTime) values(?,?)";
		return jdbcTemplate.update(sqlstmt, tweets.getTweetMsg(),tweets.getPostedTime());
	}
	@Override
	public int postedBy(Post tweets) {
		String sqlstmt = "insert into post (userEmail) values(?)";
		return jdbcTemplate.update(sqlstmt, tweets.getUserEmail());
	}
	@Override
	public int passRegistry(PasswordChecker passcheck) {
		String sqlstmt = "insert into passwordChecker (userEmail,currentpassword,pass1) values(?,?,?)";
		return jdbcTemplate.update(sqlstmt, passcheck.getUserEmail(),passcheck.getCurrentpassword(),passcheck.getPass1());
	}
	@Override
	public int insertIntoSessionDB(UserSession userSession) {
		String sqlstmt = "insert into userSession (sessionFlag,status,lastLoggedTime) values(?,?,?)";
		return jdbcTemplate.update(sqlstmt, userSession.isSessionFlag(),userSession.getStatus(),userSession.getLastLoggedTime());
	}
	@Override
	public int insertIntoStatusDB(UserStatus userStatus) {
		String sqlstmt = "insert into userStatus (userEmail) values(?)";
		return jdbcTemplate.update(sqlstmt, userStatus.getUserEmail());
	}
	
	
	@Override
	public PasswordChecker getPasswords(String username) {
		PasswordChecker actor = (PasswordChecker) this.jdbcTemplate.queryForObject(
			    "select * from passwordChecker where userEmail = ?",
			    new Object[]{username},
			    new RowMapper() {

			        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			        	PasswordChecker actor = new PasswordChecker();
			            actor.setUserEmail(rs.getString("userEmail"));
			            actor.setCurrentpassword(rs.getString("currentpassword"));
			            actor.setPass1(rs.getString("pass1"));
			            actor.setPass2(rs.getString("pass2"));
			            actor.setPass3(rs.getString("pass3"));
			            return actor;
			        }
			    });
		return actor;
	}

	@Override
	public int insertIntoAdminSessionDB(AdminSession adminSession) {
		String sqlstmt = "insert into adminSession (sessionFlag,status,lastLoggedTime) values(?,?,?)";
		return jdbcTemplate.update(sqlstmt, adminSession.isSessionFlag(),adminSession.getStatus(),adminSession.getLastLoggedTime());
	}

	@Override
	public int insertIntoStatusDB(AdminStatus adminStatus) {
		String sqlstmt = "insert into adminStatus (adminEmail) values(?)";
		return jdbcTemplate.update(sqlstmt, adminStatus.getAdminEmail());
	}

	@Override
	public int updateAdminSessionDB(String username) {
		String status="InActive";
		boolean sessionFlag=false;
		  String sql = "UPDATE adminSession SET status=?,sessionFlag=? WHERE sessionId=(select max(sessionId) from adminStatus where adminEmail=?)";
	      return jdbcTemplate.update(sql,status,sessionFlag, username);
	}

	@Override
	public int getActiveUsers() throws SQLException {
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/FDB_Final_Project_Submission","root","root");
		
		 String sql = "{call count_of_activeUsers(?)}";
		
		 CallableStatement stmt = (CallableStatement) conn.prepareCall(sql);
		 stmt.registerOutParameter(1, Types.INTEGER);
//		 stmt = dbConnection.prepareCall(call) =
		 stmt.executeQuery();
		 int count=stmt.getInt(1);
		
		 return count;
	}

	@Override
	public AdminPasswordChecker getAdminPasswords(String username) {
		AdminPasswordChecker adminPass = (AdminPasswordChecker) this.jdbcTemplate.queryForObject(
			    "select * from adminPasswordChecker where adminEmail = ?",
			    new Object[]{username},
			    new RowMapper() {

			        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			        	AdminPasswordChecker adminPass = new AdminPasswordChecker();
			        	adminPass.setAdminEmail(rs.getString("adminEmail"));
			        	adminPass.setCurrentpassword(rs.getString("currentpassword"));
			        	adminPass.setPass1(rs.getString("pass1"));
			        	adminPass.setPass2(rs.getString("pass2"));
			        	adminPass.setPass3(rs.getString("pass3"));
			            return adminPass;
			        }
			    });
		return adminPass;
	}

	@Override
	public void insertAdminPassword(String username, String password, String password2) {
		String sqlstmt = "insert into adminPasswordChecker (adminEmail,currentpassword,pass1) values(?,?,?)";
		jdbcTemplate.update(sqlstmt, username,password,password2);
		
	}

	@Override
	public int updateAdminPassword(String newPassword, String username) {
		 String sql = "UPDATE adminDetails SET adminPassword=? WHERE adminEmail=?";
	      return jdbcTemplate.update(sql, newPassword,username);
	}

	@Override
	public int updateAdminPasswordChecker(String username, String password, String newPassword, String pass2) {
		  String currentPassword=newPassword;
		  String password2=password;
		  String pass3=pass2;
		  String sql = "UPDATE adminPasswordChecker SET currentpassword=?,pass1=?,pass2=?,pass3=? WHERE adminEmail=?";
    return jdbcTemplate.update(sql, currentPassword,currentPassword,password2,pass3,username);
	}

	@Override
	public int checkPasswordIsEmpty(String username) {
		String sqlstmt = "select count(*) from adminPasswordChecker where adminEmail = ?";
		int count= this.jdbcTemplate.queryForObject(
				sqlstmt, new Object[] { username }, Integer.class);
		return count;
	}

	@Override
	public List<likes> getLikesCount() {
		String sql = "   select tweetId,count(*) as likeCount from likes group by tweetId";
		RowMapper<likes> rowMapper=new RowMapper<likes>() {
			@Override
			public likes mapRow(ResultSet rs, int rowNum) throws SQLException {
	
				String tweetId=rs.getString("tweetId");
				String likeCount=rs.getString("likeCount");
				
				return new likes(tweetId,likeCount);
			}
		};
		return jdbcTemplate.query(sql,rowMapper);
	}

	@Override
	public List<reportedDisclaimerMessage> getDisclaimerTweets() {
		String sql = " select dr.adminId,dr.reportedUser,dr.disclaimerId,dr.reportedTime, dr.tweetMsg,ct.reason from disclaimer ct join \r\n"
				+ "    (select rp.adminId,rp.reportedUser,rp.disclaimerId,rp.reportedTime, ct.tweetMsg from tweet ct join reportedDisclaimerMessage rp where ct.tweetId=rp.reportedTweetId) dr \r\n"
				+ "    where ct.disclaimerId=dr.disclaimerId";
		RowMapper<reportedDisclaimerMessage> rowMapper=new RowMapper<reportedDisclaimerMessage>() {
			@Override
			public reportedDisclaimerMessage mapRow(ResultSet rs, int rowNum) throws SQLException {
	
				String adminId=rs.getString("adminId");
				String reportedUser=rs.getString("reportedUser");
				String disclaimerId=rs.getString("disclaimerId");
				Date reportedTime=rs.getDate("reportedTime");
				String tweetMsg=rs.getString("tweetMsg");
				String reason=rs.getString("reason");
				
				return new reportedDisclaimerMessage(adminId,reportedUser,disclaimerId,reportedTime,tweetMsg,reason);
			}
		};
		return jdbcTemplate.query(sql,rowMapper);
	}  

}
