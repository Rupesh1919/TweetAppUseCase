package com.fse.usecase.model;

public class AdminAddress {

}
