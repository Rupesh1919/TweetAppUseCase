package com.fse.usecase.model;

import java.util.Date;

public class AdminDetails {
	private String adminEmail;
	private String fName;
	private String lName;
	private String gender;
	private Date dob;
	private String email;
	private String password;
	private boolean adminFlag;
	
	public AdminDetails() {
		super();
	}
	public AdminDetails(String adminEmail, String fName, String lName, String gender, Date dob, String email,
			String password, boolean adminFlag) {
		super();
		this.adminEmail = adminEmail;
		this.fName = fName;
		this.lName = lName;
		this.gender = gender;
		this.dob = dob;
		this.email = email;
		this.password = password;
		this.adminFlag = adminFlag;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isAdminFlag() {
		return adminFlag;
	}
	public void setAdminFlag(boolean adminFlag) {
		this.adminFlag = adminFlag;
	}
	

}
