package com.fse.usecase.model;

public class AdminPhnNum {
	private String adminEmail;
	private String adminPhnNumber;
	private String adminphnNumber2;
	
	public AdminPhnNum(String adminEmail, String adminPhnNumber, String adminphnNumber2) {
		super();
		this.adminEmail = adminEmail;
		this.adminPhnNumber = adminPhnNumber;
		this.adminphnNumber2 = adminphnNumber2;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getAdminPhnNumber() {
		return adminPhnNumber;
	}
	public void setAdminPhnNumber(String adminPhnNumber) {
		this.adminPhnNumber = adminPhnNumber;
	}
	public String getAdminphnNumber2() {
		return adminphnNumber2;
	}
	public void setAdminphnNumber2(String adminphnNumber2) {
		this.adminphnNumber2 = adminphnNumber2;
	}
	

}
