package com.fse.usecase.model;

import java.util.Date;

public class AdminSession {
	private String sessionId;
	private boolean sessionFlag;
	private String status;
	private Date lastLoggedTime;
	
	public AdminSession(boolean sessionFlag, String status, Date lastLoggedTime) {
		super();
		this.sessionFlag = sessionFlag;
		this.status = status;
		this.lastLoggedTime = lastLoggedTime;
	}
	public AdminSession(String sessionId, boolean sessionFlag, String status, Date lastLoggedTime) {
		super();
		this.sessionId = sessionId;
		this.sessionFlag = sessionFlag;
		this.status = status;
		this.lastLoggedTime = lastLoggedTime;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public boolean isSessionFlag() {
		return sessionFlag;
	}
	public void setSessionFlag(boolean sessionFlag) {
		this.sessionFlag = sessionFlag;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getLastLoggedTime() {
		return lastLoggedTime;
	}
	public void setLastLoggedTime(Date lastLoggedTime) {
		this.lastLoggedTime = lastLoggedTime;
	}
	

}
