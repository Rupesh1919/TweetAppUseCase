package com.fse.usecase.model;

public class AdminStatus {
	private String adminEmail;
	private String sessionId;
	
	public AdminStatus(String adminEmail) {
		super();
		this.adminEmail = adminEmail;
	}
	public AdminStatus(String adminEmail, String sessionId) {
		super();
		this.adminEmail = adminEmail;
		this.sessionId = sessionId;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	

}
