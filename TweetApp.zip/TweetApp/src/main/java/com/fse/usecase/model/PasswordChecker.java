package com.fse.usecase.model;

import java.util.Date;

public class PasswordChecker {
	private String userEmail;
	private String currentpassword;
	private String pass1;
	private String pass2;
	private String pass3;
	
	public PasswordChecker(String userEmail, String currentpassword, String pass1, String pass2, String pass3) {
		super();
		this.userEmail = userEmail;
		this.currentpassword = currentpassword;
		this.pass1 = pass1;
		this.pass2 = pass2;
		this.pass3 = pass3;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getCurrentpassword() {
		return currentpassword;
	}
	public void setCurrentpassword(String currentpassword) {
		this.currentpassword = currentpassword;
	}
	public String getPass1() {
		return pass1;
	}
	public void setPass1(String pass1) {
		this.pass1 = pass1;
	}
	public String getPass2() {
		return pass2;
	}
	public void setPass2(String pass2) {
		this.pass2 = pass2;
	}
	public String getPass3() {
		return pass3;
	}
	public void setPass3(String pass3) {
		this.pass3 = pass3;
	}
	public PasswordChecker(String userEmail, String currentpassword, String pass1) {
		super();
		this.userEmail = userEmail;
		this.currentpassword = currentpassword;
		this.pass1 = pass1;
	}
	public PasswordChecker() {
		super();
	}
	

}
