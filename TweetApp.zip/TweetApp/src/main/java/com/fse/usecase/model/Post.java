package com.fse.usecase.model;

public class Post {
	private String tweetId;
	private String userEmail;
	
	public Post(String userEmail) {
		super();
		this.userEmail = userEmail;
	}
	public Post(String tweetId, String userEmail) {
		super();
		this.tweetId = tweetId;
		this.userEmail = userEmail;
	}
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	

}
