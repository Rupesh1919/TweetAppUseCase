package com.fse.usecase.model;

import java.util.Date;

public class Tweet {
	private String tweetId;
	private String tweetMsg;
	private Date postedTime;
	
	
	public Tweet(String tweetMsg, Date postedTime) {
		super();
		this.tweetMsg = tweetMsg;
		this.postedTime = postedTime;
	}

	public Tweet(String tweetId, String tweetMsg, Date postedTime) {
		super();
		this.tweetId = tweetId;
		this.tweetMsg = tweetMsg;
		this.postedTime = postedTime;
	}
	
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}
	public String getTweetMsg() {
		return tweetMsg;
	}
	public void setTweetMsg(String tweetMsg) {
		this.tweetMsg = tweetMsg;
	}
	public Date getPostedTime() {
		return postedTime;
	}
	public void setPostedTime(Date postedTime) {
		this.postedTime = postedTime;
	}
	

}
