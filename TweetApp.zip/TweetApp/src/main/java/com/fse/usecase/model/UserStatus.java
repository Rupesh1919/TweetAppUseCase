package com.fse.usecase.model;

public class UserStatus {
	private String userEmail;
	private String sessionId;
	
	public UserStatus(String userEmail) {
		super();
		this.userEmail = userEmail;
	}
	public UserStatus(String userEmail, String sessionId) {
		super();
		this.userEmail = userEmail;
		this.sessionId = sessionId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	

}
