package com.fse.usecase.model;

import java.util.Date;
public class UserphnNumber {
	private String userEmail;
	private String phnNumber1;
	private String phnNumber2;
	
	public UserphnNumber(String userEmail, String phnNumber1, String phnNumber2) {
		super();
		this.userEmail = userEmail;
		this.phnNumber1 = phnNumber1;
		this.phnNumber2 = phnNumber2;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getPhnNumber1() {
		return phnNumber1;
	}
	public void setPhnNumber1(String phnNumber1) {
		this.phnNumber1 = phnNumber1;
	}
	public String getPhnNumber2() {
		return phnNumber2;
	}
	public void setPhnNumber2(String phnNumber2) {
		this.phnNumber2 = phnNumber2;
	}
	

}

