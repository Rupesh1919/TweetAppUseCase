package com.fse.usecase.model;

import java.util.Date;

public class likes {
	private String tweetId;
	private String likeCount;
	private String Likedby;
	
	public likes() {
		super();
	}
	
	public likes(String tweetId, String likeCount) {
		super();
		this.tweetId = tweetId;
		this.likeCount = likeCount;
	}

	public likes(String tweetId, String likeCount, String likedby) {
		super();
		this.tweetId = tweetId;
		this.likeCount = likeCount;
		Likedby = likedby;
	}
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}
	public String getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(String likeCount) {
		this.likeCount = likeCount;
	}
	public String getLikedby() {
		return Likedby;
	}
	public void setLikedby(String likedby) {
		Likedby = likedby;
	}
	

}
