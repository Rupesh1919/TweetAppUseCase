package com.fse.usecase.model;

import java.util.Date;

public class reportedDisclaimerMessage {
	private String adminEmail;
	private String reportedUser;
	private String disclaimerId;
	private Date reportedTime;
	private String tweetMsg;
	private String reason;
	
	public reportedDisclaimerMessage(String adminEmail, String reportedUser, String disclaimerId, Date reportedTime,
			String tweetMsg, String reason) {
		super();
		this.adminEmail = adminEmail;
		this.reportedUser = reportedUser;
		this.disclaimerId = disclaimerId;
		this.reportedTime = reportedTime;
		this.tweetMsg = tweetMsg;
		this.reason = reason;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getReportedUser() {
		return reportedUser;
	}
	public void setReportedUser(String reportedUser) {
		this.reportedUser = reportedUser;
	}
	public String getDisclaimerId() {
		return disclaimerId;
	}
	public void setDisclaimerId(String disclaimerId) {
		this.disclaimerId = disclaimerId;
	}
	public Date getReportedTime() {
		return reportedTime;
	}
	public void setReportedTime(Date reportedTime) {
		this.reportedTime = reportedTime;
	}
	public String getTweetMsg() {
		return tweetMsg;
	}
	public void setTweetMsg(String tweetMsg) {
		this.tweetMsg = tweetMsg;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	

}
