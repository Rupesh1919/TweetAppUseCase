package com.fse.usecase.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.dao.TweetDaoImpl;
import com.fse.usecase.model.AdminDetails;
import com.fse.usecase.model.AdminPasswordChecker;
import com.fse.usecase.model.AdminSession;
import com.fse.usecase.model.AdminStatus;
import com.fse.usecase.model.PasswordChecker;
import com.fse.usecase.model.UserAddress;
import com.fse.usecase.model.UserSession;
import com.fse.usecase.model.UserStatus;
import com.fse.usecase.model.UserphnNumber;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.Zipcode;
import com.fse.usecase.model.userTweets;

@Service
public class LoginServices {

	@Autowired
	private TweetDao tweetDao;
	
	public int registerUserIntoDB(Users user)
	{
		int p=tweetDao.registerUser(user);
		return p;
	}
	
	public int registerUserAddressIntoDB(UserAddress useradd)
	{
		int p=tweetDao.registerAddrUser(useradd);
		return p;
	}
	
	public int registerUserOtherDetailsIntoDB(UserphnNumber user)
	{
		int p=tweetDao.register2User(user);
		return p;
	 }
	
	public int updatePassword(String newPassword,String email)
	{
		int k=tweetDao.updatePassword(newPassword, email);
		return k;
	}
	public int updateSessionDB(String email)
	{
		int k=tweetDao.updateSessionDB(email);
		return k;
	}
	
	public int updatePasswordChecker(String username,String password,String newPassword,String pass3)
	{
		int k=tweetDao.updatePasswordChecker(username, password,newPassword,pass3);
		return k;
	}
	
	public boolean loginCheck(String username,String passcode)
	{
		String keyPattern="@tweet.com";
		if(username.contains(keyPattern)) {
//			List<AdminDetails> allUsers=tweetDao.allAdmins();
			String adminPasscode=tweetDao.getAdminPassword(username);
			if(adminPasscode==null) {
				return false;
			}
			if(adminPasscode.equals(adminPasscode)) {
				return true;
			}
			return false;
			
		}else {
			List<Users> allUsers=tweetDao.allUsers();
			for (Users users : allUsers) {
				if(users.getEmail().equals(username)&&users.getPassword().equals(passcode))
				{
					return true;
				}
			}
			return false;
		}
		
	}
	
	public int passwordChecker(PasswordChecker passcheck)
	{
		int p=tweetDao.passRegistry(passcheck);
		return p;
	}
	public int insertIntoSessionDB(UserSession userSession)
	{
		int p=tweetDao.insertIntoSessionDB(userSession);
		return p;
	}
	
	public int insertIntoStatusDB(UserStatus userStatus)
	{
		int p=tweetDao.insertIntoStatusDB(userStatus);
		return p;
	}
	public int registerZipToDB(Zipcode zip)
	{
		boolean k=tweetDao.getZip(zip.getZipcode());
		if(!k) {
			int p=tweetDao.registerZipToDB(zip);
			return p;
		}
		return 1;
		
	}
	public boolean passwordChecker(String username,String passcode,String newPassword) {
		PasswordChecker passcheck=tweetDao.getPasswords(username);
		if(passcheck.getPass1()!=null) {
			if(passcheck.getPass1().equals(newPassword)) {
				return false;
			}
		}else if(passcheck.getPass2()!=null) {
			if(passcheck.getPass2().equals(newPassword)) {
				return false;
			}
		}else if(passcheck.getPass2()!=null){
			if(passcheck.getPass3().equals(newPassword)) {
				return false;
			}
		}
		
		
		return true;
	}
	public PasswordChecker getPasswords(String username) {
		PasswordChecker passcheck=tweetDao.getPasswords(username);
		return passcheck;
	}
	public List<Users> getAllUsers()
	{
		List<Users> allUsers=tweetDao.allUsers();
		return allUsers;
	}

	public int insertIntoAdminSessionDB(AdminSession adminSession) {
		int p=tweetDao.insertIntoAdminSessionDB(adminSession);
		return p;
	}

	public int insertIntoAdminStatusDB(AdminStatus userStatus) {
		int p=tweetDao.insertIntoStatusDB(userStatus);
		return p;
	}

	public int updateAdminSessionDB(String username) {
		int k=tweetDao.updateAdminSessionDB(username);
		return k;
	}

	public int getActiveUsers() throws SQLException {
		int k=tweetDao.getActiveUsers();
		return k;
	}

	public boolean adminPasswordChecker(String username, String password, String newPassword) {
		int k=tweetDao.checkPasswordIsEmpty(username);
		if(k==0) {
			tweetDao.insertAdminPassword(username,password,password);
			return true;
		}
		AdminPasswordChecker passcheck=tweetDao.getAdminPasswords(username);
		
		if(passcheck.getPass1()!=null) {
			if(passcheck.getPass1().equals(newPassword)) {
				return false;
			}
		}else if(passcheck.getPass2()!=null) {
			if(passcheck.getPass2().equals(newPassword)) {
				return false;
			}
		}else if(passcheck.getPass2()!=null){
			if(passcheck.getPass3().equals(newPassword)) {
				return false;
			}
		}
		
		
		return true;
	}

	public AdminPasswordChecker getAdminPasswords(String username) {
		AdminPasswordChecker passcheck=tweetDao.getAdminPasswords(username);
		return passcheck;
	}

	public int updateAdminPasswordChecker(String username, String password, String newPassword, String pass2) {
		int k=tweetDao.updateAdminPasswordChecker(username, password,newPassword,pass2);
		return k;
	}

	public int updateAdminPassword(String newPassword, String username) {
		int k=tweetDao.updateAdminPassword(newPassword, username);
		return k;
	}

	
}
