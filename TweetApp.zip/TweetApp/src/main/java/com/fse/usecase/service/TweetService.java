package com.fse.usecase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fse.usecase.dao.TweetDao;
import com.fse.usecase.model.Post;
import com.fse.usecase.model.Tweet;
import com.fse.usecase.model.Users;
import com.fse.usecase.model.likes;
import com.fse.usecase.model.reportedDisclaimerMessage;
import com.fse.usecase.model.userTweets;

@Service
public class TweetService {

	@Autowired
	private TweetDao tweetDao;
	
	public List<userTweets> getAllTweetsFroomDB(){
		
		List<userTweets> allTweets=tweetDao.getAllTweets();
		return allTweets;
	}
	
	public List<userTweets> getAllMyTweetsFromDB(String email)
	{
		return tweetDao.getAllMyTweets(email);
	}
	public int postTweet(Tweet user)
	{
		int p=tweetDao.postTweet(user);
		return p;
	}
	public int postedBy(Post post)
	{
		int p=tweetDao.postedBy(post);
		return p;
	}

	public List<likes> getLikesCount() {
		List<likes> allTweets=tweetDao.getLikesCount();
		return allTweets;
	}

	public List<reportedDisclaimerMessage> getDisclaimerTweets() {
		// TODO Auto-generated method stub
		List<reportedDisclaimerMessage> allDisTweets=tweetDao.getDisclaimerTweets();
		return allDisTweets;
	}
}
