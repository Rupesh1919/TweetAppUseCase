import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertifyService } from '../_services/alertify.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {
  

  constructor(private userService: UserService, private router: Router,private alertifyService: AlertifyService) { }

  users:any;
  ngOnInit(): void {

    this.userService.getAllUsers().subscribe(response => {
      this.users=response;
  },(error) => {
    console.log(error);
    this.ngOnInit();
  })
}

}
