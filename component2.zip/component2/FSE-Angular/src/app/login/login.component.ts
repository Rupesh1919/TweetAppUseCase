import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { AlertifyService } from '../_services/alertify.service';
import { UserService } from '../_services/user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginForm:any;
  errorMessage:any;
  constructor(private userService:UserService,private router:Router,private alertifyService: AlertifyService) { 
    
    
  }
  

  ngOnInit() {
   
    this.loginForm = new FormGroup({
      'email': new FormControl('', [Validators.required]),
      'password': new FormControl('', [Validators.required])
      })

  }

  loginsubmit(loginForm:any)
  {
    console.log(loginForm);
    this.errorMessage=null;
    this.userService.loginuser(loginForm.value).subscribe((response:any) =>{
      console.log(response)
      if(response.errorMessage!==null)
      {
        
        this.errorMessage=response.errorMessage;
        this.alertifyService.error(this.errorMessage);
      }
      else{
        this.userService.setFlag(true);
        sessionStorage.setItem('email', response.email);
        sessionStorage.setItem('token', response.token);
        this.router.navigate(['/homepage'])
        this.alertifyService.success("you have been logged in");
      }
    },(error) => {
      console.log(error);
      
       })
  }
  

}
