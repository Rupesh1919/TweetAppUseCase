import { Injectable } from '@angular/core';
import { CanActivate, Router} from '@angular/router';
import { UserService } from '../user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
    flag=false;
  constructor(private userService: UserService, private router: Router ){
    this.userService.setFlag(false);
    this.userService.getFlag().subscribe(flag => {

      this.flag=flag;
    });
  }
  
  canActivate(): boolean  {
    if (this.flag===true){
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }
  }